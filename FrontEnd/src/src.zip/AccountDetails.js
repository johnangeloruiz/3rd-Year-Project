import React, { useState, useEffect, useRef } from 'react';
import UpdatePassword from './UpdatePassword';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import shoppingcart from './Images/Shopping Cart.jpg'
import aieslogo from './Images/AIEs Logo.jpg'
import UpdateMeetUpPlace from './UpdateMeetUpPlace';
import UpdateSelectedLocation from './UpdateSelectedLocation';
import UpdateCellphoneNumber from './UpdateCellphoneNumber'
import Register from './Register';
import Logout from './Logout'
import Login from './Login'
function AccountDetails() {
    const [accountData, setAccountData] = useState(null);
    const [newItemsCount, setNewItemsCount] = useState(0);
    
  const UserLogin = window.localStorage.getItem("isLogin");
  const [activeLink, setActiveLink] = useState('home');
    const email = window.localStorage.getItem('email');
    const [showUpdatePassword, setShowUpdatePassword] = useState(false);
    const [showUpdateMeetUpPlace, setShowUpdateMeetUpPlace] = useState(false);
    const [showUpdateSelectedLocation, setShowUpdateSelectedLocation] = useState(false);
    const [isProductsLinkClicked, setProductsLinkClicked] = useState(false);
    const [showUpdateCellphoneNumber, setShowUpdateCellphoneNumber] = useState(false);
    const productsSectionRef = useRef();
    const [showRegisterModal, setShowRegisterModal] = useState(false);
    const navigate = useNavigate()
  const [showLogoutModal, setShowLogoutModal] = useState(false);
    const handleShowUpdateCellphoneNumber = () => setShowUpdateCellphoneNumber(true);
    const handleCloseUpdateCellphoneNumber = () => setShowUpdateCellphoneNumber(false);
  
    const handleUpdateCellphoneNumberClick = () => {
      handleShowUpdateCellphoneNumber();
    };
    const handleShowUpdateSelectedLocation = () => setShowUpdateSelectedLocation(true);
const handleCloseUpdateSelectedLocation = () => setShowUpdateSelectedLocation(false);

    const handleShowUpdatePassword = () => setShowUpdatePassword(true);
    const handleCloseUpdatePassword = () => setShowUpdatePassword(false);
    const handleShowUpdateMeetUpPlace = () => setShowUpdateMeetUpPlace(true);
  const handleCloseUpdateMeetUpPlace = () => setShowUpdateMeetUpPlace(false);
  // Add handlers for other modals if needed
  const [isUpdatePasswordModalOpen, setUpdatePasswordModalOpen] = useState(false);

  const openLogoutModal = () => {
    setShowLogoutModal(true);
};

const closeLogoutModal = () => {
    setShowLogoutModal(false);
};
  const handleProductsClick = () => {
    setProductsLinkClicked(true);
    productsSectionRef.current.scrollIntoView({ behavior: 'smooth' });
    setNewItemsCount(0); // Reset new items count
  };
  const confirmLogout = () => {
    // Perform logout actions here
    window.localStorage.removeItem("email");
    window.localStorage.removeItem("isLogin");
    navigate('/');
    closeLogoutModal();
    window.location.reload()
  };
  const [showLogin, setShowLogin] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const handleLoginShow = () => setShowLogin(true);
  const handleLoginClose = () => setShowLogin(false);

  const fetchAccountData = async () => {
    try {
      const response = await fetch(`http://localhost:8081/getDataAccount?email=${email}`);
      const data = await response.json();
      setAccountData(data.account);
    } catch (error) {
      console.error('Error fetching account data:', error);
    }
  };

  useEffect(() => {
    fetchAccountData();
  }, []);

  const handleUpdatePasswordClick = () => {
    setUpdatePasswordModalOpen(true);
  };

  const handleCloseModal = () => {
    setUpdatePasswordModalOpen(false);
  };
    // Assume you have a function to fetch account data from your backend
    const handleButtonClick = () => {
      setShowRegisterModal(true);
    };
  
    const handleRegisterButtonClick = () => {
      setShowRegisterModal(true);
    };
    const handleRegisterModalClose = () => {
      setShowRegisterModal(false);
    };
    const handleLoginButtonClick = () => {
      
      setShowLoginModal(true);
    };
  
    const handleLoginModalClose = () => {
      setShowLoginModal(false);
      window.location.reload()
    };
    useEffect(() => {
        fetchAccountData();
    }, []);

    return (
        <div>
          <div>
          <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <Link className="navbar-brand" to="/">
          <img className="logo"src={aieslogo}></img>
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav mx-auto">
            <li className="nav-item">
              <Link
                className={activeLink === 'home' ? 'nav-link active' : 'nav-link'}
                to="/"
              >
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link
                className={activeLink === 'products' ? 'nav-link active' : 'nav-link'}
                to="/#products"
                onClick={handleProductsClick}
              >
                Products
              </Link>
            </li>
            <li className="nav-item">
              <NavLink className="nav-link" to="/About">
                About
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink className="nav-link" to="/Contacts">
                Contacts
              </NavLink>
            </li>
          </ul>
        </div>
        <div className="navbar-nav ml-auto">
          <li className="nav-item">
            <NavLink className="nav-link" to="/Cart">
              <img className="cartSize" src={shoppingcart} alt="Shopping Cart" />
            </NavLink>
          </li>
          {UserLogin ? (
      <div>
        <NavLink to="/AccountDetails">{email}</NavLink>
        <li className="nav-item logout">
      
      <button onClick={openLogoutModal}>Log Out</button>

<Logout
  isOpen={showLogoutModal}
  onCancel={closeLogoutModal}
  onConfirm={confirmLogout}
/>
    </li>
      </div>
      
          ) : (
            <li className="nav-item  logout">
               <button className='loginbtn' onClick={handleLoginButtonClick} >Login</button>
               {showLoginModal && <Login showModal={showLoginModal} onClose={handleLoginModalClose} />}
               
               <button type="button" className="registerbtn" onClick={handleRegisterButtonClick}>
        Register
      </button>

               {showRegisterModal && <Register showModal={showRegisterModal} onClose={handleRegisterModalClose}/>}

            </li>
          )}
        </div>
      </nav>
          </div>
            {accountData ? (
                <div>
                    <h1>First Name</h1>
                    <p>{accountData.firstname}</p>
                    <h1>Last Name</h1>
                    <p>{accountData.lastname}</p>
                    <h1>Email</h1>
                    <p>{accountData.email}</p>
                    <h1>Password</h1>
                    <p>*************</p>
                    <button variant="primary" onClick={handleShowUpdatePassword}>
        Update Password
      </button>

      <UpdatePassword show={showUpdatePassword} onClose={handleCloseUpdatePassword} email={email}/>
      <h1>MeetUpPlace</h1>
      <p>{accountData.meetUpPlace}</p>
          <button onClick={handleShowUpdateMeetUpPlace}>Update MeetUpPlace</button>
          <UpdateMeetUpPlace show={showUpdateMeetUpPlace} onClose={handleCloseUpdateMeetUpPlace} email={email} />
                    <h1>Selected Location</h1>
<p>{accountData.selectedLocation}</p>
<button onClick={handleShowUpdateSelectedLocation}>Update Selected Location</button>

<UpdateSelectedLocation
  show={showUpdateSelectedLocation}
  onClose={handleCloseUpdateSelectedLocation}
  email={email}
/>
<h1>CellPhone Number</h1>
<p>{accountData.cellphoneNumber}</p>
<button variant="primary" onClick={handleUpdateCellphoneNumberClick}>
        Update Cellphone Number
      </button>
      <UpdateCellphoneNumber
        show={showUpdateCellphoneNumber}
        onClose={handleCloseUpdateCellphoneNumber}
        email={email}
      />
                </div>
            ) : (
                <p>Loading account details...</p>
            )}
        </div>
    );
}

export default AccountDetails;
