import React, { useState } from 'react';
import { Modal, Form, Button } from 'react-bootstrap';

function UpdatePassword({ show, onClose, userEmail }) {
  const [newPassword, setNewPassword] = useState('');
  const email = window.localStorage.getItem('email')
  const handlePasswordChange = async () => {
    try {
      const response = await fetch('http://localhost:8081/UpdatePassword', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email,
          newPassword: newPassword,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        // Password updated successfully
        console.log(data.message);
        onClose();
      } else {
        alert(data.error)
        console.error('Error updating password:', data.error);
      }
    } catch (error) {
      console.error('Error updating password:', error);
    }
  };

  return (
    <Modal show={show} onHide={onClose} animation={false}>
      <Modal.Header closeButton>
        <Modal.Title>Update Password</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          <Form.Group controlId="formNewPassword">
            <Form.Label>New Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Enter new password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
            />
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
        <Button variant="primary" onClick={handlePasswordChange}>
          Update Password
        </Button>
      </Modal.Footer>
    </Modal>
  );
}

export default UpdatePassword;
